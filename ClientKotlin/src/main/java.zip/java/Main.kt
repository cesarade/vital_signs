import org.phoenixframework.Socket
import kotlin.random.Random



fun main(args: Array<String>) {
    //    connectoToChannel()

    val client1 = Client(
        "cfe8c81b-9c39-4ee1-96d7-f6ad28ff731b",
        "http://localhost:4000/socket/websocket",
        "client1@emial.com",
    "sp1",
    TypeHeartRate.Normal)

    client1.connectSocket()
    client1.connectChannel()

    val client2 = Client(
        "df206c29-bfd0-448d-940b-c7ca37617f20",
        "http://localhost:4000/socket/websocket",
        "client2@emial.com",
        "sp1",
        TypeHeartRate.NormalTraining)

    client2.connectSocket()
    client2.connectChannel()

    val vitalSigns = VitalSigns()
    vitalSigns.addClient(client1)
    vitalSigns.addClient(client2)

    vitalSigns.connect()
    vitalSigns.send()




//    client2.sendVitalSigns()
//    client1.sendVitalSigns()

    val heartRate = Random.nextInt(60, 100)
    println(heartRate)
}